public class Main{
	
	public static void main(String args[]){
		Minimax m = new Minimax();
		m.run();
	}
}